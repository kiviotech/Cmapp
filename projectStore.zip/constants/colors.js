
export default {
    primary: '#577CFF',
    background: '#F5F5F5', // Background color
    loginPageTextColor: '#006E75',
    blackColor: '#000',
    borderColor: '#B3B3B3',
    whiteColor: '#FFF',
    loginSignUpLabelColor: '#9796A1',
    greenessColor: '#A3D65C',
    radiusColor: '#FC5275'
};