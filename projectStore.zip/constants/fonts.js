
export default {
  WorkSans400: "WorkSans_400Regular",
  WorkSans500: "WorkSans_500Medium",
  WorkSans600: "WorkSans_600SemiBold",
  WorkSans700: "WorkSans_700Bold",
};