import icons from './icons'
import svgs from './svgs'
export {icons, svgs}