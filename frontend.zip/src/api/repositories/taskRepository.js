import apiClient from "../apiClient";
import taskEndpoints from "../endpoints/taskEndpoints";

export const getTasks = (userId, page, pageSize, designation_value) =>
  apiClient.get(
    taskEndpoints.getTasks(userId, page, pageSize, designation_value)
  );

export const getTaskById = (id) => apiClient.get(taskEndpoints.getTaskById(id));

export const getTaskDetailsById = (id) =>
  apiClient.get(taskEndpoints.getTaskDetailsById(id));

export const createTask = (data) =>
  apiClient.post(taskEndpoints.createTask, data);

export const updateTask = (id, data) =>
  apiClient.put(taskEndpoints.updateTask(id), data);

export const deleteTask = (id) =>
  apiClient.delete(taskEndpoints.deleteTask(id));

export const getTasksByUserAndProject = (id, projectId) =>
  apiClient.get(taskEndpoints.getTasksByUserAndProject(id, projectId));

export const getTasksByUser = (id) =>
  apiClient.get(taskEndpoints.getTasksByUser(id));

export const getTaskByContractorId = (projectId, id) =>
  apiClient.get(taskEndpoints.getTaskByContractorId(projectId, id));

export const getTasksBySubmissionId = (id) =>
  apiClient.get(taskEndpoints.getTasksBySubmissionId(id));
