import date from '../assets/icons/png/date.png';
import facebook from '../assets/icons/png/facebook.png';
import google from '../assets/icons/png/google.png';
import eye from '../assets/icons/png/eye.png';
import eyeHide from '../assets/icons/png/eyeHide.png';
import user1 from '../assets/icons/png/user1.png';
import user2 from '../assets/icons/png/user2.png';
import reUpload from '../assets/icons/png/reUpload.png';
import upload from '../assets/icons/png/upload.png';
import bell from '../assets/icons/png/bell.png';
import search from '../assets/icons/png/search.png';
import filters from '../assets/icons/png/filters.png';
import home from '../assets/icons/png/upload.png';
import user from '../assets/icons/png/user.png';
import settings from '../assets/icons/png/settings.png';
import logout from '../assets/icons/png/logout.png';
export default {
    date,
    facebook,
    google,
    eye,
    eyeHide,
    user1,
    user2,
    reUpload,
    upload,
    bell,
    search, filters, home, user, settings, logout
}